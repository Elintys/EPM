export interface EventState{
    
}